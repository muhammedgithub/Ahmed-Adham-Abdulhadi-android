package com.Ahmed.myapplicationn;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.wael.myapplicationn.R;

public class MainActivity extends AppCompatActivity {

    private  TextView lblUN1,lblPW1, lblresult1 ;
    private  Button btnSum1;
    private  EditText txtFN1, txtSN1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lblUN1 = (TextView) findViewById(R.id.lblFN);
        lblPW1 = (TextView) findViewById(R.id.lblSN);
        lblresult1= (TextView) findViewById(R.id.lblResult);

        txtFN1 = (EditText) findViewById(R.id.txtFN);
        txtSN1 = (EditText) findViewById(R.id.txtSN);

        btnSum1 = (Button) findViewById(R.id.btnSum);


        btnSum1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value1 = txtFN1.getText().toString();
                String value2 = txtSN1.getText().toString();

                int x= Integer.parseInt(value1);
                int y= Integer.parseInt(value2);

                int sum = x + y;

                lblresult1.setText(String.valueOf(sum));
            }
        });






    }
}
